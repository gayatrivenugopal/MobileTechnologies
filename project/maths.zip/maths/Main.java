package com.example.maths;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;


public class Main extends Activity {
private Button a;
private Button b;
private Button c;
private Button d;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		
		
		
		a=(Button)findViewById(R.id.one);
		b=(Button)findViewById(R.id.two);
		c=(Button)findViewById(R.id.three);
		d=(Button)findViewById(R.id.back);
		a.setOnClickListener(new OnClickListener() {
        	public void onClick(View v)
        	{
        		Intent obj=new Intent(getApplicationContext(),Linearequation.class);
        		startActivity(obj);
        		finish();
        		
        	}
        });
              
		b.setOnClickListener(new OnClickListener() {
        	public void onClick(View v)
        	{
        		Intent obj=new Intent(getApplicationContext(),Linearequation1.class);
        		startActivity(obj);
        		finish();
        		
        	}
        });
       
		c.setOnClickListener(new OnClickListener() {
        	public void onClick(View v)
        	{
        		Intent obj=new Intent(getApplicationContext(),QuadraticEquation.class);
        		startActivity(obj);
        		finish();
        		
        	}
        });
		
		d.setOnClickListener(new OnClickListener() {
        	public void onClick(View v)
        	{
        		Intent obj=new Intent(getApplicationContext(),MainActivity.class);
        		startActivity(obj);
        		finish();
        		
        	}
        });
		
		
			Intent myIntent = getIntent();
			if (myIntent.hasExtra("myExtra")){                                TextView mText = (TextView)findViewById(R.id.textView);
			mText.setText("Welcome "+myIntent.getStringExtra("myExtra")+"!"); }
    
	
}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}

package com.example.maths;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import android.view.View.OnClickListener;

public class QuadraticEquation extends Activity {
private Button aa;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.quadratic_equation);
    Button b = (Button)this.findViewById(R.id.answer);
    b.setOnClickListener(new Button.OnClickListener() {
    	public void onClick(View v)
    	{
    		EditText a = (EditText) findViewById(R.id.a);
    		EditText b = (EditText) findViewById(R.id.b);
    		EditText c = (EditText) findViewById(R.id.c);
    		TextView d = (TextView) findViewById(R.id.d);
    		TextView e = (TextView) findViewById(R.id.e);
    		float i= Float.parseFloat(a.getText().toString());
    		float j= Float.parseFloat(b.getText().toString());
    		float k= Float.parseFloat(c.getText().toString());
    		k=k*(-1);
    		float l=((j*j)-(4*i*k));
    		double m,n,o;
    		
    		if(l>0)
    		{
    			 m=Math.sqrt(l);
        		 n=(double)(((-1)*j+m)/(2*i));
        		 o=(double)(((-1)*j-m)/(2*i));
    			e.setText("Roots are real and distinct");
    			String str1=Double.toString(n);
    			String str2=Double.toString(o);
        		String str="The roots of X are="+str1+" & "+str2;
        		d.setText(str);
    		}
    		else if(l==0)
    		{
    			 m=Math.sqrt(l);
        		 n=(double)(((((-1)*j)+m))/(2*i));
        		 
    			e.setText("Roots are real and equal");
    			String str1=Double.toString(n);
    			
        		String str="The roots of X are="+str1;
        		d.setText(str);
    		}
    		else
    		{
    			l=l*(-1);
    			 m=Math.sqrt(l);
        		 n=(double)((-1)*j)/2;
    			e.setText("Roots are unreal and distinct");
    			m=(m/(2*i));
    			String str1=Double.toString(m);
    			String str2=Double.toString(n);
        		String str="The roots of X are="+str2+"+"+str1+"i & "+str2+"-"+str1+"i";
        		d.setText(str);
    		}

    		
    		
    		
    	}
    });
    aa=(Button)findViewById(R.id.back);
    aa.setOnClickListener(new OnClickListener() {
    	public void onClick(View v)
    	{
    		Intent obj=new Intent(getApplicationContext(),Main.class);
    		startActivity(obj);
    		finish();
    		
    	}
    });
	
	
	}
	
	
	
	
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.quadratic_equation, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}

package com.example.maths;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import android.view.View.OnClickListener;

public class Linearequation1 extends Activity {
public Button aa;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_linearequation1);
    Button b = (Button)this.findViewById(R.id.answer);
    b.setOnClickListener(new Button.OnClickListener() {
    	public void onClick(View v)
    	{
    		EditText a = (EditText) findViewById(R.id.a);
    		EditText b = (EditText) findViewById(R.id.b);
    		EditText c = (EditText) findViewById(R.id.c);
    		EditText e = (EditText) findViewById(R.id.e);
    		EditText f = (EditText) findViewById(R.id.f);
    		EditText g = (EditText) findViewById(R.id.g);
    		TextView d = (TextView) findViewById(R.id.d);
    		float i= Float.parseFloat(a.getText().toString());
    		float j= Float.parseFloat(b.getText().toString());
    		float k= Float.parseFloat(c.getText().toString());
    		float l= Float.parseFloat(e.getText().toString());
    		float m= Float.parseFloat(f.getText().toString());
    		float n= Float.parseFloat(g.getText().toString());
    		
    		float x=(((j*n)-(k*m))/((j*l)-(i*m)));
    		float y=(((-1)*(i*x)+k)/j);
    		String str1=Float.toString(x);
    		String str2=Float.toString(y);
    		String str="The value of X is ="+str1+"& Y is="+str2;
    		d.setText(str);
    		
    	}
    });
	
	
    aa=(Button)findViewById(R.id.back);
    aa.setOnClickListener(new OnClickListener() {
    	public void onClick(View v)
    	{
    		Intent obj=new Intent(getApplicationContext(),Main.class);
    		startActivity(obj);
    		finish();
    		
    	}
    });
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.linearequation1, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}

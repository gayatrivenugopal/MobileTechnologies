package com.example.maths;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Linearequation extends Activity {
private Button aa;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_linearequation);
    Button b = (Button)this.findViewById(R.id.answer);
    b.setOnClickListener(new Button.OnClickListener() {
    	public void onClick(View v)
    	{
    		EditText a = (EditText) findViewById(R.id.a);
    		EditText b = (EditText) findViewById(R.id.b);
    		EditText c = (EditText) findViewById(R.id.c);
    		TextView d = (TextView) findViewById(R.id.d);
    		float i= Float.parseFloat(a.getText().toString());
    		float j= Float.parseFloat(b.getText().toString());
    		float k= Float.parseFloat(c.getText().toString());
    		j=j*(-1);
    		float l=(j+k)/i;
    		String str1=Float.toString(l);
    		String str="The value of X is ="+str1;
    		d.setText(str);
    		
    	}
    });
	
	
	
	 aa=(Button)findViewById(R.id.back);
	    aa.setOnClickListener(new OnClickListener() {
	    	public void onClick(View v)
	    	{
	    		Intent obj=new Intent(getApplicationContext(),Main.class);
	    		startActivity(obj);
	    		finish();
	    		
	    	}
	    });
	
	
	}
	
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.linearequation, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
